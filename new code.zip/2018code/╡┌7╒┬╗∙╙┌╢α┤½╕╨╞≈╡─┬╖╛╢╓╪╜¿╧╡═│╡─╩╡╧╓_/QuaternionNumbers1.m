%%%%�ú�������Ϊ��ŷ����x y zתΪ��Ԫ�� q0 q1 q2 q3
function [q0,q1,q2,q3]=QuaternionNumbers1(x,y,z)

C11=cos(x)*cos(z);
C12=sin(x)*cos(z)*sin(y)-sin(z)*cos(y);
C13=sin(x)*cos(z)*cos(y)+sin(z)*sin(y);

C21=cos(x)*sin(z);
C22=sin(x)*cos(z)*sin(y)+cos(z)*cos(y);
C23=sin(x)*sin(z)*cos(y)-cos(z)*sin(y);

C31=-sin(x);
C32=cos(x)*sin(y);
C33=cos(x)*cos(y);

% C11=cos(y)*cos(z)-sin(y)*sin(x)*sin(z);
% C12=-cos(x)*sin(z);
% C13=sin(y)*cos(z)+cos(y)*sin(x)*sin(z);
% 
% C21=cos(y)*sin(z)+sin(y)*sin(x)*cos(z);
% C22=cos(x)*cos(z);
% C23=sin(y)*sin(z)-cos(y)*sin(x)*cos(z);
% 
% C31=-sin(y)*cos(x);
% C32=sin(x);
% C33=cos(y)*cos(x);

C=[C11,C12,C13;C21,C22,C23;C31,C32,C33];

q0=0.5*sqrt(1+C11+C22+C33);
q1=0.5*sqrt(1+C11-C22-C33)*sign(C32-C23);
q2=0.5*sqrt(1-C11+C22-C33)*sign(C13-C31);
q3=0.5*sqrt(1-C11-C22+C33)*sign(C21-C12);

 
end
