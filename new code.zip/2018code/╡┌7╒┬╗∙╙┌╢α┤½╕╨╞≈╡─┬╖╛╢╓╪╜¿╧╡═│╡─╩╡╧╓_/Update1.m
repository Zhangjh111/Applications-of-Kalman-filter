function [Angel,Acc]=Update1(QQ,AC_data)
Angel=[];
Acc=[];
for i=2:length(QQ)
 q0=QQ(1,i); 
 q1=QQ(2,i); 
 q2=QQ(3,i); 
 q3=QQ(4,i);
 
 T11=q0^2+q1^2-q2^2-q3^2;
 T12=2*(q1*q2-q0*q3);
 T13= 2*(q1*q3+q0*q2);
 T21=2*(q1*q2+q0*q3);
 T22=q0^2-q1^2+q2^2-q3^2;
 T23=2*(q2*q3-q0*q1);
 T31=2*(q1*q3-q0*q2);
  T32=2*(q2*q3+q0*q1);
  T33=q0^2-q1^2-q2^2+q3^2;
  T=[T11 T12 T13;T21 T22 T23;T31 T32 T33];


 x1=-asin(T31);
y1=atan(T32/T33);

z1=atan(T21/T11);
  
   
    if  abs(T31)<1
       x=x1;
   elseif (T31)>=1
       x=pi/2;
   elseif (T31)<=-1
       x=-pi/2;
   end
   
  if T33>0
  y=y1;
  else
      if y1<0
          y=y1+pi;
      elseif y1>0
          y=y1-pi;

      end
  end
  
   if T11<0
  z=z1+pi;
  else
      if z1>0
          z=z1;
      elseif z1<0
          z=z1+2*pi;

      end
  end
% Ac=T*AC_data(i,:)'+[0;0;10.1];
 Ac=T*AC_data(i,:)';
  Ac=AC_data(i,:)';
%  
 angel=[x*180/pi;y*180/pi;z*180/pi];
 % angel=[x;y;z];
 Angel=[Angel angel];
 Acc=[Acc Ac];
end