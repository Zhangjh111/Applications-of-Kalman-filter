tic
% function mytrackingbySeveralMethod
clc
clear
summ=0;N=1;covvv=[];
for n=1:N

imm=xlsread('DisplacementTimeHistory.xlsx');  %%����ʵ�����ݣ�������Ϊ·��
% load acc
%  imm=imm1(1:10,:);
 s=imm(:,2); 
%  s=s1(1:10);
% s=facc(2,:);
% M=1;
% imm1=0:0.1:57.8;
% s=imm(:,2)
%%%%�������������
R= 2.8;%
% RMSEimm=sqrt(sum((imm(:,2)-imm(:,3)).^2)/length(imm));
%%%%%%%%%%%ѡ��ģ�Ͳ���
M=1;
 a=1/20;
 xamax=5;
 qq=(xamax)^2*(4-pi)/pi;
 C=[1 0];
 xe=zeros(2,1);
 p=100000*eye(2);
 TT=0.001;

%%%ʹ����С���˹���Yule-Walker����
[xx1,xxe1,aa1,qq1,Ea1,RR01,RR11,P331,MM1,PP1,QQ,aaa]=funDataDrivenModelYW(C,TT,R,a,qq,xe,p,s,M);
y=[s(1)  C*xxe1(:,2:length(s))]';y=y(1:10); 
% z1=imm(:,3);z=z1(1:10);
% covv=cov(z'-y');%����ʵֵ�Ƚϵķ���
% summ=summ+covv;
% nrmse=length(z);
% RMSE=sqrt(sum((z-y).^2)/nrmse);
% sum1=[];
% for i=1:length(z)
%     a3=abs(z(i)-y(i));
%     sum1=[sum1 a3];
%     c3=mean(sum1);
% end
% disp(c3);
end

summ/N 
toc
%%%%%%%%%%%%%%%%%%%%%%%��ͼ����
% xlswrite('DenoiseDisplacement.xls',[s(1)  C*xxe1(:,2:length(s))]')
% xlswrite('DenoiseForce.xls',[s(1)  C*xxe1(:,2:length(s))]')
% 
% 
subplot(2,1,1);plot(imm(:,1),s,'b-'),
hold on,
plot(imm(:,1),[s(1)  C*xxe1(:,2:length(s))],'r-')
legend('the measurement data','the denoise data')

ylabel('data')
subplot(2,1,2); plot(imm(:,1),imm(:,3),'k-')
hold on,
plot(imm(:,1),[s(1)  C*xxe1(:,2:length(s))],'r-')
legend('the real data','the denoise data')

figure
plot(imm(:,1),imm(:,3)'-[s(1)  C*xxe1(:,2:length(s))])



